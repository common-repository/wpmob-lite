

=== WPMOB LITE BOOKMARK ICON TEMPLATE v1 ===

The icon template is designed to create a great bookmark icon for iPhone/iPod touch, whether you have the glossy icon setting on or off.

1. Do not change the size of the icon

The size of the icon, including the border, etc has been formatted to work properly for both glossy and non-glossy icons. Changing the image size will cause your icon to become cut-off or stretched.

2. PNG Only

Make sure you save your finished image in the .PNG format. The iPhone, iPad and iPod touch will only show the bookmark icon if it's a PNG.